﻿using UnityEngine;
using System.Collections;

public class xxx : MonoBehaviour {

    public AnimationCurve anim;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = new Vector3(Time.time, anim.Evaluate(Time.time), 0);
    }
}
