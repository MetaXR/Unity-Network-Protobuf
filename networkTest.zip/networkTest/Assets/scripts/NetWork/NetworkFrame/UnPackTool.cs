using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using protocol;
using ProtoBuf;
using System.IO;

namespace NetWorkFrame
{
public class UnPackTool
{
public static IExtensible UnPack(ENetworkMessage networkMessage, int startIndex, int length, byte[] buffer)
{
  IExtensible packet = null;

  try
{
  using (MemoryStream streamForProto = new MemoryStream(buffer, startIndex, length))
{
  switch (networkMessage)
{
case ENetworkMessage.KEEP_ALIVE_SYNC:
packet = Serializer.Deserialize<KeepAliveSync>(streamForProto);
break;
case ENetworkMessage.OFFLINE_SYNC:
packet = Serializer.Deserialize<OffLineSync>(streamForProto);
break;
//进入大厅请求，返回
case ENetworkMessage.ENTER_LIVE_HALL_REQ:
packet = Serializer.Deserialize<EnterLiveHallReq>(streamForProto);
break;
case ENetworkMessage.ENTER_LIVE_HALL_RSP:
packet = Serializer.Deserialize<EnterLiveHallRsp>(streamForProto);
break;
//退出大厅请求，返回
case ENetworkMessage.EXIT_LIVE_HALL_REQ:
packet = Serializer.Deserialize<ExitLiveHallReq>(streamForProto);
break;
case ENetworkMessage.EXIT_LIVE_HALL_RSP:
packet = Serializer.Deserialize<ExitLiveHallRsp>(streamForProto);
break;
//进入一个直播房间请求，返回，同步
case ENetworkMessage.ENTER_LIVE_ROOM_REQ:
packet = Serializer.Deserialize<EnterLiveRoomReq>(streamForProto);
break;
case ENetworkMessage.ENTER_LIVE_ROOM_RSP:
packet = Serializer.Deserialize<EnterLiveRoomRsp>(streamForProto);
break;
case ENetworkMessage.ENTER_LIVE_ROOM_SYNC:
packet = Serializer.Deserialize<EnterLiveRoomSync>(streamForProto);
break;
//退出一个直播房间请求，返回，同步
case ENetworkMessage.EXIT_LIVE_ROOM_REQ:
packet = Serializer.Deserialize<ExitLiveRoomReq>(streamForProto);
break;
case ENetworkMessage.EXIT_LIVE_ROOM_RSP:
packet = Serializer.Deserialize<ExitLiveRoomRsp>(streamForProto);
break;
case ENetworkMessage.EXIT_LIVE_ROOM_SYNC:
packet = Serializer.Deserialize<ExitLiveRoomSync>(streamForProto);
break;
//移动位置请求，返回，同步
case ENetworkMessage.MOVE_POSITION_REQ:
packet = Serializer.Deserialize<MovePositionReq>(streamForProto);
break;
case ENetworkMessage.MOVE_POSITION_RSP:
packet = Serializer.Deserialize<MovePositionRsp>(streamForProto);
break;
case ENetworkMessage.MOVE_POSITION_SYNC:
packet = Serializer.Deserialize<MovePositionSync>(streamForProto);
break;
//说话状态请求，返回，同步
case ENetworkMessage.TALKING_REQ:
packet = Serializer.Deserialize<TalkingReq>(streamForProto);
break;
case ENetworkMessage.TALKING_RSP:
packet = Serializer.Deserialize<TalkingRsp>(streamForProto);
break;
case ENetworkMessage.TALKING_SYNC:
packet = Serializer.Deserialize<TalkingSync>(streamForProto);
break;
//发送表情请求，返回，同步
case ENetworkMessage.SEND_CHAT_REQ:
packet = Serializer.Deserialize<SendChatReq>(streamForProto);
break;
case ENetworkMessage.SEND_CHAT_RSP:
packet = Serializer.Deserialize<SendChatRsp>(streamForProto);
break;
case ENetworkMessage.RECEIVE_CHAT_SYNC:
packet = Serializer.Deserialize<ReceiveChatSync>(streamForProto);
break;
default:
Log4U.LogInfo("No Such Packet, packet type is " + networkMessage);
break; 
 }
}
}
catch (System.Exception ex)
{
Log4U.LogError(ex.Message + "\n " + ex.StackTrace + "\n" + ex.Source);

}return packet;
}
}
}
